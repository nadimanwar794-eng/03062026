
export type ClassLevel = '6' | '7' | '8' | '9' | '10' | '11' | '12' | 'COMPETITION';

export type Board = 'BSEB' | 'NCERT_EN' | 'NCERT_HI' | 'COMPETITION';

export type Stream = 'Science' | 'Commerce' | 'Arts';

export type Role = 'STUDENT' | 'TEACHER' | 'ADMIN' | 'SUB_ADMIN';

export interface TimeConfig {
    days: number;
    hours: number;
    minutes: number;
    seconds: number;
}

export interface FrequencyConfig {
    value: number;
    unit: 'seconds' | 'minutes' | 'hours' | 'days' | 'months' | 'years';
}

export type ContentType = 'NOTES_SIMPLE' | 'NOTES_PREMIUM' | 'MCQ_ANALYSIS' | 'MCQ_SIMPLE' | 'MCQ_RESULT' | 'PDF_FREE' | 'PDF_PREMIUM' | 'PDF_ULTRA' | 'PDF_VIEWER' | 'WEEKLY_TEST' | 'VIDEO_LECTURE' | 'NOTES_HTML_FREE' | 'NOTES_HTML_PREMIUM' | 'NOTES_IMAGE_AI' | 'TEACHING_STRATEGY';

export interface PrizeRule {
  id: string;
  category: 'SYLLABUS_MCQ' | 'WEEKLY_TEST' | 'DAILY_CHALLENGE';
  minQuestions: number; // e.g., 50 for syllabus, or total for test
  minPercentage: number; // e.g., 90%
  rewardType: 'COINS' | 'SUBSCRIPTION';
  rewardAmount?: number; // for COINS
  rewardSubTier?: 'WEEKLY' | 'MONTHLY' | 'LIFETIME';
  rewardSubLevel?: 'BASIC' | 'ULTRA';
  rewardDurationHours?: number; // for SUBSCRIPTION
  label: string;
  enabled: boolean;
}

export interface ExternalApp {
  id: string;
  name: string;
  url: string;
  icon?: string; // Optional icon name or url
  isLocked: boolean;
  creditCost: number;
}

// NEW: Download App for the in-app App Store page
export type DownloadAppStore = 'PLAY_STORE' | 'GOOGLE_DRIVE' | 'MEDIAFIRE' | 'APP_STORE' | 'OTHER';

export interface DownloadApp {
  id: string;
  name: string;
  description?: string;
  iconUrl?: string;
  downloadUrl: string;
  store: DownloadAppStore;
  version?: string;
  size?: string;
}

export interface SubjectProgress {
  currentChapterIndex: number; // Starts at 0 (Chapter 1)
  totalMCQsSolved: number; // Must reach 100 to advance index
}

export interface PrizeEntry {
  id: string;
  userId: string;
  userName: string;
  prize: string;
  reason: string;
  date: string;
  scorePercentage: number;
}

export interface InboxMessage {
  id: string;
  text: string;
  date: string;
  read: boolean;
  type?: 'TEXT' | 'REWARD' | 'GIFT' | 'STORE_DISCOUNT';
  redeemCode?: string;
  discountPercent?: number;
  reward?: {
      tier: 'WEEKLY' | 'MONTHLY' | 'YEARLY' | 'LIFETIME';
      level: 'BASIC' | 'ULTRA';
      durationHours: number;
  };
  gift?: {
      type: 'CREDITS' | 'SUBSCRIPTION' | 'ANIMATION';
      value: number | string;
      durationHours?: number;
  };
  expiresAt?: string;
  isClaimed?: boolean;
}

export interface DailyRoutine {
    date: string;
    tasks: RoutineTask[];
    focusArea: string;
}

export interface RoutineTask {
    title: string;
    duration: number; // minutes
    type: 'REVISION' | 'NEW_TOPIC' | 'PRACTICE' | 'BREAK' | 'DEEP_DIVE';
    description?: string;
    subject?: string;
}

export interface User {
  id: string; // Login ID (Firebase UID)
  displayId?: string; // Visible ID (IIC-XXX)
  password: string;
  name: string;
  mobile: string;
  email: string;
  role: Role;
  teacherCode?: string;
  teacherExpiryDate?: string; // The code used to register as a teacher
  createdAt: string;
  credits: number; // Premium Credits
  streak: number; // Consecutive days
  longestStreak?: number; // All-time highest streak
  topBarEffectColor?: string; // Custom shimmer color gifted via redeem code
  tempThemeColor?: string; // Temporary app-wide subscription color (from THEME_COLOR redeem code)
  tempThemeColorExpiry?: string; // ISO string — when tempThemeColor expires
  personalThemeColor?: string; // User's own permanently chosen theme color (from ThemeCustomizer)
  personalTheme?: UserCustomTheme; // Full granular permanent theme
  activeAppliedThemeId?: string; // 'default' | ThemeHistoryEntry.id — user's chosen theme from admin history
  useDefaultTheme?: boolean; // User explicitly chose default tier theme — skip all admin overrides
  themeBadgeColor?: string;
  themeAnimationId?: string;
  themePublishedAt?: string;
  animationPublishedAt?: string;
  customTheme?: UserCustomTheme;
  customAnimation?: UserCustomAnimation;
  activeThemeAppliedUntil?: string;
  activeAnimationAppliedUntil?: string;
  level?: number; // Current Level (Default 1)
  xp?: number; // Current XP
  lastLoginDate: string; // ISO Date string YYYY-MM-DD
  lastActiveTime?: string; // ISO String for "Online" status
  totalActiveDays?: number; // NEW: Total days active (for Level System)
  redeemedCodes: string[]; // List of redeemed code IDs
  redeemedReferralCode?: string; // NEW: Code used by this user
  referralCount?: number; // NEW: Number of users referred by this user
  
  // Soft Delete / Ban Logic
  isArchived?: boolean; // Acts as Soft Delete / Recycle Bin
  isLocked?: boolean;   // NEW: Hard Lock (Login Denied, but not deleted)
  deletedAt?: string; // ISO Date when deleted. If > 30 days, auto purge.
  recoveryCode?: string; // Generated by Admin to restore account
  isPasswordless?: boolean; // NEW: Allow login without password (Admin Approved Recovery)
  
  // GRANULAR BANS
  isChatBanned?: boolean; // Can't send messages
  isGameBanned?: boolean; // Can't play Spin Wheel
  
  // ROLE & PERMISSIONS
  isSubAdmin?: boolean; // If true, role is effectively ADMIN but with restricted permissions
  permissions?: string[]; // List of allowed feature codes e.g. ['MANAGE_SUBS', 'VIEW_USERS']

  // COMMUNICATION
  inbox?: InboxMessage[]; // Messages from Admin
  
  // REWARDS SYSTEM
  pendingRewards?: PendingReward[];
  isRewardsUnlocked?: boolean; // 10 Coin Gate
  isAutoDeductEnabled?: boolean; // NEW: Skip confirmation popup for credit spending

  // New Fields for Student Profile
  board?: string;
  classLevel?: string;
  stream?: string; // Only for 11/12
  provider?: 'google' | 'manual';
  securityQuestion?: string;
  securityAnswer?: string;
  photoURL?: string;
  /** Loading-screen item ownership and slot assignments, synced across devices. */
  loadingScreenSlotUnlocks?: Record<string, boolean>;
  loadingScreenUnlocks?: Record<string, number>;
  loadingScreenSlotAssignments?: Record<string, number>;
  avatarChoice?: 'gmail' | 'app';
  linkedGoogleUid?: string;
  linkedGoogleEmail?: string;
  profileCompleted?: boolean;
  
  // Chat & Premium Features
  isPremium?: boolean;
  lastChatTime?: string; // ISO String for cooldown
  lastSpinTime?: string; // ISO String (Legacy)
  dailySpinDate?: string; // YYYY-MM-DD for resetting daily count
  dailySpinCount?: number; // Number of spins used today
  dailyAiDate?: string; // NEW: Track AI usage date
  dailyAiCount?: number; // NEW: Track AI usage count
  lastRewardClaimDate?: string; // To track daily 3-hour study reward
  lastLoginRewardDate?: string; // NEW: Daily Login Bonus (10 coins)
  storeDiscount?: number; // NEW: Personal Store Discount %
  totalScore?: number; // Cumulative activity score for score-based store discounts
  lastScoreDate?: string; // ISO Date string of last score update
  scoreBoostPercent?: number; // Active score boost % from SCORE_BOOST redeem code
  scoreBoostExpiry?: string; // ISO Date when score boost expires
  personalThemeExpiry?: string; // ISO Date when user's temporary custom theme expires (set during score boost event)
  scoreLimitBoostPercent?: number; // Temporary daily score limit boost % from SCORE_LIMIT_BOOST redeem code
  scoreLimitBoostExpiry?: string; // ISO Date when daily limit boost expires (reverts to default after this)
  bonusCredits?: number; // Permanent credits awarded with subscription (never expire)
  giftedCredits?: number; // Admin-gifted credits (separate from earned/bonus)
  giftedCreditsExpiry?: string; // ISO date when gifted credits expire
  lastLevelNotified?: number; // Last level the user was shown a level-up celebration for
  dailyMcqDate?: string; // YYYY-MM-DD for daily MCQ tracking
  dailyMcqCount?: number; // MCQs attempted today
  dailyMcqCorrect?: number; // Correct MCQs today
  dailyMcqRewardClaimed?: boolean; // Whether reward claimed today
  dailyWriteDate?: string; // YYYY-MM-DD for write mode tracking
  dailyWriteCount?: number; // Write mode unlocks today
  dailyVideoDate?: string; // YYYY-MM-DD for video tracking
  dailyVideoCount?: number; // Videos watched today
  dailyPdfDate?: string; // YYYY-MM-DD for PDF tracking
  dailyPdfCount?: number; // PDFs viewed today
  totalMcqSolved?: number; // All-time MCQs answered (cumulative)
  totalVideoWatched?: number; // All-time videos watched (cumulative)
  totalPdfViewed?: number; // All-time PDFs viewed (cumulative)
  totalWriteUsed?: number; // All-time write mode unlocks (cumulative)
  
  // SUBSCRIPTION MANAGEMENT
  subscriptionTier?: 'FREE' | 'WEEKLY' | 'MONTHLY' | '3_MONTHLY' | 'YEARLY' | 'LIFETIME' | 'CUSTOM'; // Added 3_MONTHLY and CUSTOM
  subscriptionLevel?: 'BASIC' | 'ULTRA'; // NEW: Granular level for Real subscribers
  subscriptionEndDate?: string; // ISO Date when subscription expires
  subscriptionPrice?: number; // Price admin set for this user's subscription
  grantedByAdmin?: boolean; // True if subscription was granted free by admin
  customSubscriptionName?: string; // For CUSTOM tier
  customSubscriptionDuration?: {
    years: number;
    months: number;
    days: number;
    hours: number;
    minutes: number;
    seconds: number;
  };
  
  // Progress Tracking
  progress: Record<string, SubjectProgress>; // Key is subjectID
  
  // New Analytics Data
  mcqHistory?: MCQResult[]; // List of all completed tests
  customMcqs?: MCQItem[]; // Student-created practice MCQs (Competition page)
  topicStrength?: Record<string, { correct: number, total: number }>; // Key: subjectId or topicId
  usageHistory?: UsageHistoryEntry[];
  subscriptionHistory?: SubscriptionHistoryEntry[];
  activeSubscriptions?: ActiveSubscription[]; // NEW: For concurrent subscriptions
  testResults?: MCQResult[];
  unlockedContent?: string[];
  timedUnlocks?: { contentId: string; expiresAt: string }[];
  dailyRoutine?: DailyRoutine;
  subjectFreeLesson?: Record<string, string>; // subjectId → chapterId (first free lesson per subject)
}

export interface ActiveSubscription {
  id: string;
  tier: 'WEEKLY' | 'MONTHLY' | '3_MONTHLY' | 'YEARLY' | 'LIFETIME' | 'CUSTOM';
  level: 'BASIC' | 'ULTRA'; // 'BASIC' or 'ULTRA'
  startDate: string;
  endDate: string;
  source: 'PURCHASE' | 'REWARD' | 'ADMIN' | 'BONUS';
}

export interface MarksheetSettings {
  appName: string;
  developedBy: string;
  pyqInspired?: string;
}

export interface SubscriptionHistoryEntry {
  id: string;
  tier: string; // 'WEEKLY', 'MONTHLY', etc.
  level: string; // 'BASIC', 'ULTRA'
  startDate: string;
  endDate: string;
  durationHours: number;
  price: number; // Amount paid (or 0)
  originalPrice: number; // Value of the plan
  isFree: boolean; // True if reward/admin grant
  grantSource: 'PURCHASE' | 'REWARD' | 'ADMIN' | 'BONUS';
  grantedBy?: string; // ID of the Admin/Sub-Admin who granted this
  grantedByName?: string; // Name of the Admin/Sub-Admin
}

export interface UsageHistoryEntry {
  id: string;
  type: 'VIDEO' | 'PDF' | 'MCQ' | 'GAME' | 'PURCHASE' | 'VIEW' | 'AUDIO';
  itemId: string;
  itemTitle: string;
  subject: string;
  durationSeconds?: number;
  amount?: number;
  timestamp: string;
}

export interface CreditPackage {
  id: string;
  name: string;
  credits: number;
  price: number;
  dummyPrice?: number; // NEW: Strike-through dummy price
  color?: string; // Visual color for the card
}

export interface SubscriptionPlan {
  id: string;
  name: string;
  duration: string; // e.g., "7 days", "30 days"
  
  // Basic Tier (MCQ + Notes)
  basicPrice: number;
  basicOriginalPrice: number;
  
  // Advance/Ultra Tier (PDF + Video)
  ultraPrice: number;
  ultraOriginalPrice: number;
  
  features: string[]; // Generic features list or split logic
  popular?: boolean;
}

export interface RecycleBinItem {
  id: string; // Unique delete ID
  originalId: string; // ID of the actual item
  type: 'USER' | 'CHAPTER' | 'CONTENT' | 'POST' | 'MCQ_BATCH' | 'HOMEWORK_ENTRY' | 'LUCENT_ENTRY' | 'CONTENT_DATA';
  firebaseCollection?: string;
  name: string; // For display
  data: any; // Full object to restore
  deletedAt: string;
  expiresAt: string; // 90 days later
  restoreKey?: string; // LocalStorage key to restore to
}

export interface PaymentRequest {
  id: string;
  userId: string;
  userName: string;
  packageId: string;
  packageName: string;
  amount: number;
  txnId: string; // User entered Transaction ID/UTR
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  timestamp: string;
}

// NEW INTERFACE
export interface RecoveryRequest {
  id: string; // User ID
  name: string;
  mobile: string;
  timestamp: string;
  status: 'PENDING' | 'RESOLVED';
}

export interface StartupConfig {
    enabled: boolean;
    duration: number; // Seconds
    title: string;
    features: string[]; // List of text
    bgColor: string;
    textColor: string;
}

export interface BannerSettings {
    text: string;
    enabled: boolean;
    autoHideSeconds: number;
    bgColor?: string;
    textColor?: string;
    clickUrl?: string;
    liveVideoUrl?: string;
}

export interface BannerItem {
    id: string;
    imageUrl: string;
    actionUrl?: string; // Optional link
    isActive: boolean;
}

export interface ExploreBanner {
    id: string;
    title: string;
    subtitle?: string;
    imageUrl?: string;
    backgroundStyle?: string; // CSS background property (gradient or color)
    actionUrl?: string; // Internal tab ID or External URL
    actionLabel?: string;
    targetAudience?: 'ALL' | 'FREE' | 'PREMIUM';
    enabled: boolean;
    priority: number;
}

export interface FeatureAccessConfig {
    featureId: string;
    label: string;
    allowedTiers: ('FREE' | 'BASIC' | 'ULTRA')[];
    creditCost?: number; // Global override cost
    isDummy?: boolean; // Visual indicator if feature is implemented or placeholder
    limits?: {
        free?: number;
        basic?: number;
        ultra?: number;
    };
}

export interface FeatureCostConfig {
    featureId: string;
    freeCost: number;
    basicCost: number;
    ultraCost: number;
}

export interface LoginBonusRandomGiftOption {
    type: 'DISCOUNT' | 'SUBSCRIPTION' | 'EFFECT' | 'CREDITS';
    weight: number; // relative probability weight (higher = more likely)
    amount?: number; // for CREDITS type
    discountPercent?: number; // for DISCOUNT type
    subTier?: 'DAILY' | 'WEEKLY' | 'MONTHLY'; // for SUBSCRIPTION type
    subLevel?: 'BASIC' | 'ULTRA'; // for SUBSCRIPTION type
    effectId?: string; // for EFFECT type
    label?: string;
}

export interface LoginBonusConfig {
    freeBonus: number;
    basicBonus: number;
    ultraBonus: number;
    strictStreak: boolean;
    randomGiftEnabled?: boolean;
    randomGiftChance?: number; // 0-100 percent chance each login
    randomGiftOptions?: LoginBonusRandomGiftOption[];
}

export interface BroadcastRedeemCode {
    id: string;
    code: string;
    type: 'CREDITS' | 'SUBSCRIPTION' | 'DISCOUNT' | 'CONTENT_UNLOCK' | 'TOPBAR_EFFECT_COLOR' | 'TOPBAR_EFFECT_ID' | 'SCORE' | 'SCORE_BOOST' | 'SCORE_LIMIT_BOOST';
    scoreBoostPercent?: number; // For SCORE_BOOST type — how much % to boost score by
    scoreBoostDurationHours?: number; // How long the boost lasts
    scoreLimitBoostPercent?: number; // For SCORE_LIMIT_BOOST type — temporary daily limit increase %
    scoreLimitBoostDurationHours?: number; // How long the daily limit boost lasts (hours)
    message: string;
    title?: string;
    amount?: number;
    scoreAmount?: number; // For SCORE type — how many score points to add
    discountPercent?: number;
    subTier?: string;
    subLevel?: string;
    effectColor?: string;
    effectId?: string;
    contentId?: string;
    maxUses?: number; // undefined = single use; set to large number for multi-use
    isMultiUse?: boolean; // if true, can be used by multiple accounts
    durationHours?: number; // how long the code is valid after delivery
    sentAt: string;
    expiresAt?: string; // when this broadcast itself expires
    targetTier?: 'ALL' | 'FREE' | 'BASIC' | 'ULTRA'; // who to send to
}

export interface EventBannerConfig {
    type: 'DISCOUNT' | 'FREE_EVERYTHING' | 'CREDITS_FREE' | 'MAINTENANCE' | 'UPDATE' | 'COUPON' | 'CUSTOM';
    title: string;
    subtitle?: string;
    imageUrl?: string;
    actionUrl?: string; // Deep link or External
    enabled: boolean;
    bgColor?: string;
    textColor?: string;
}

export interface TeacherCode {
    code: string;
    isActive: boolean;
    price: number;
    createdBy: string;
    createdAt: string;
    durationDays?: number;
    uses: number;
}

export interface TeacherStorePlan {
    id: string;
    name: string;
    price: number;
    durationDays: number;
    benefits: string[];
    isActive: boolean;
}

export interface DailyGkItem {
  id: string;
  date: string;
  question: string;
  answer: string;
}

export interface HomeworkItem {
  id: string;
  date: string;
  title: string;
  /** Board filter: when set, only students in this board see this item. Unset = shown to all. */
  board?: 'BSEB' | 'NCERT_EN' | 'NCERT_HI';
  notes?: string;
  mcqText?: string;
  parsedMcqs?: MCQItem[];
  audioUrl?: string;
  videoUrl?: string;
  pdfUrl?: string;
  targetSubject?: string;
  pageNo?: string; // Optional page number for page-wise notes (Sar Sangrah / Speedy etc.)
  topicName?: string; // Optional topic name for compare-based topic matching across books
  /** Plain-text notes for Read Mode (TTS ChunkedNotesReader). Falls back to notes if absent. */
  chunkNotes?: string;
  /** HTML/CSS formatted notes for Write Mode (Smart HTML view). Falls back to notes if absent. */
  htmlNotes?: string;
  /** Custom CSS applied only in White/Light mode for this note's HTML content. Auto-scoped. */
  lightCSS?: string;
  /** Custom CSS applied in both Dark (black) and Blue mode for this note's HTML content. Auto-scoped. */
  darkCSS?: string;
}

export interface LucentPageNote {
  id: string;
  pageNo: string;
  content: string;
  /** Optional date associated with this page (ISO YYYY-MM-DD). Shown in the
   *  reader so the student knows when the page was added / which day's notes. */
  date?: string;
  /** Optional admin-curated MCQs for this specific page. When present, the
   *  reader shows them under the MCQ tab instead of AI-generating from text. */
  mcqs?: MCQItem[];
  /** Optional topic name tag for compare-based topic matching across books.
   *  When set, compare view will find this exact topic from all books. */
  topicName?: string;
  /** Plain-text notes for Read Mode (TTS ChunkedNotesReader).
   *  When set, the Read Mode reader uses this instead of stripping HTML from content. */
  chunkNotes?: string;
  /** HTML/CSS formatted notes for Write Mode (Smart HTML view).
   *  When set, Write Mode renders this as rich HTML. Falls back to content if absent. */
  htmlNotes?: string;
  /** Custom CSS applied only in White/Light mode for this page's HTML content. Auto-scoped. */
  lightCSS?: string;
  /** Custom CSS applied in both Dark (black) and Blue mode for this page's HTML content. Auto-scoped. */
  darkCSS?: string;
  /** Optional Google Drive (or YouTube) video link for this page.
   *  Shown as an embedded player in the reader — no Gmail login required
   *  when the Drive file is shared as "Anyone with the link". */
  videoUrl?: string;
  /** Optional PDF link (Google Drive or direct URL) for this page.
   *  Opens in a PDF viewer when the student taps "PDF" in the content picker. */
  pdfUrl?: string;
  /** Optional audio URL for this page. */
  audioUrl?: string;
}

export interface LucentNoteEntry {
  id: string;
  subject: string; // 'biology' | 'chemistry' | 'physics' | 'economics' | 'geography' | 'polity' | 'history'
  /** Custom-named "book" label as the admin entered it. Optional — falls back
   *  to the matching LUCENT_SUBJECT name when absent. Used as the displayed
   *  book title in Class 6-12 / Competition chapter list. */
  bookName?: string;
  /**
   * Target class for this lesson. When set to a Class 6-12 value, this lesson
   * appears in that class's chapter list using the same Competition-style
   * page-wise notes/MCQ viewer (video/audio rendering for that class is
   * untouched — only notes & MCQ format borrows from Competition mode).
   * Defaults to 'COMPETITION' for backward compat with existing entries.
   */
  classLevel?: '6' | '7' | '8' | '9' | '10' | '11' | '12' | 'COMPETITION';
  /** Board filter: when set, only students in this board see this lesson. Unset = shown to all boards. */
  board?: 'BSEB' | 'NCERT_EN' | 'NCERT_HI';
  lessonTitle: string;
  pages: LucentPageNote[];
  createdAt?: string;
  /** When true, this lesson is locked behind a Redeem Code.
   *  Students need a valid code (or an admin-generated timedUnlock / permanent unlock)
   *  to open it. Admins always bypass the gate. */
  locked?: boolean;
  /** When true, this entry contains ONLY MCQs — no page-wise notes.
   *  Students tap the title and are taken directly to MCQ view (no popup, no page list). */
  mcqOnly?: boolean;
  /** When true, this lesson is permanently free for ALL users — Book Text, Smart Notes,
   *  और आसान समझ (Explanation) sab unlock hote hain, daily reading limit nahi lagti.
   *  Har subject mein ek "sample" lesson ke liye use karo. */
  isSampleLesson?: boolean;
}

export interface AppNotification {
  id: string;
  title: string;
  body: string;
  type: 'info' | 'reward' | 'CONTENT';
  rewardCredits?: number;
  createdAt: string;
  expiresAt?: string; // ISO date — auto-hidden after this time (e.g. 7 days for content alerts)
}

export interface SystemSettings {
  notifications?: AppNotification[];
  broadcastRedeemCodes?: BroadcastRedeemCode[];
  loadingScreenVideoUrl?: string; // NEW: Video to show before loading screen
  /** 'default' = current white card login, 'video' = fullscreen looping video bg */
  loginPageStyle?: 'default' | 'video';
  loginVideoUrl?: string;
  dailyGk?: DailyGkItem[]; // NEW: Daily GK
  homework?: HomeworkItem[];
  lucentNotes?: LucentNoteEntry[];
  /**
   * When true (default), the built-in / AI-generated Lucent syllabus chapters are
   * hidden in the student app. Only admin-added Lucent lessons (page-wise notes)
   * are shown — organised subject-wise, then page-wise.
   */
  hideLucentSyllabus?: boolean;
  /**
   * When true, class 6-12 students see ONLY admin-added Lucent-style lessons.
   * Traditional school-mode notes (CONTENT_PDF system) are hidden for class 6-12.
   * Default false (both systems visible).
   */
  class612LucentMode?: boolean;
  /**
   * Admin-controlled "social proof" boost for the global Trending Notes page
   * and ⭐ saved-count badges. This is the LOW end of the per-note boost
   * range. If `globalNotesFakeBoostMax` is greater, each note gets a
   * deterministic random boost in [min, max] (seeded by note hash, so it
   * stays stable across renders) — this prevents every note from showing
   * the same boosted number which would look fake. 0 = no boost.
   */
  globalNotesFakeBoost?: number;
  /**
   * Upper end of the per-note boost range. When > `globalNotesFakeBoost`,
   * each note's display boost varies between min and max (deterministically
   * per note). When equal/less, behaves as flat boost.
   */
  globalNotesFakeBoostMax?: number;
  /**
   * Optional minimum displayed ⭐ count. If a note's actual+boost count is
   * below this, it will display as this minimum instead. 0 = disabled.
   */
  globalNotesFakeMin?: number;
  globalChallengeMcq?: MCQItem[]; // NEW: Global Challenge MCQ
  competitionMcqs?: MCQItem[]; // Admin-created MCQs visible on Competition page
  googleAuthOnly?: boolean;
    teacherCodes?: TeacherCode[];
  appName: string; // Long Name
  activeEvents?: EventBannerConfig[]; // NEW: Event Banners
  mcqUnlockThreshold?: number; // NEW: Customizable unlock threshold
  mcqTestLimitFree?: number;
  mcqLimitFree?: number; // Daily Limit Free
  mcqLimitBasic?: number; // Daily Limit Basic
  mcqLimitUltra?: number; // Daily Limit Ultra
  /** Admin override for per-level daily limits. Key = "1"–"11". */
  levelLimitsOverride?: Record<string, {
    mcq?:   { free?: number; basic?: number; ultra?: number };
    dl?:    { free?: number; basic?: number; ultra?: number };
    pdf?:   { free?: number; basic?: number; ultra?: number };
    video?: { free?: number; basic?: number; ultra?: number };
    notes?: { free?: number; basic?: number; ultra?: number };
    tts?:   { free?: number; basic?: number; ultra?: number };
    write?: { free?: number; basic?: number; ultra?: number };
    creditWriteMax?:    number;
    bonusLoginCredits?: number;
  }>;
  /** Max books allowed in one Compare session. 0 = unlimited. */
  compareLimitFree?: number;   // default 2
  compareLimitBasic?: number;  // default 5
  compareLimitUltra?: number;  // default 0 (unlimited)
  mcqTestLimitBasic?: number;
  mcqAnalysisCostBasic?: number;
  mcqAnalysisCostUltra?: number;
  mcqHistoryCost?: number;
  mcqTestCost?: number;
  mcqAnalysisCost?: number;
  appShortName?: string; // e.g. "IIC"
  appShortNameSize?: number; // Font size in pixels for loading-screen short name (admin slider, 24-120). Default 30.
  developerName?: string; // Shown as "Developed by …" on the loading screen and profile page. Default "Nadim Anwar".
  /** Admin-defined extra "books" (Sar Sangrah / Speedy ki tarah). Each entry becomes:
   *   - a target-subject option in the Homework form (admin)
   *   - a subject card on the student dashboard, opening a flat page-wise list of notes/MCQs
   *  Items are stored as homework entries with `targetSubject = book.id`. */
  customBooks?: { id: string; name: string; type?: 'single' | 'multi' }[];
  contentCodeExpiry?: { days: number; hours: number; minutes: number };
  splashFontId?: string; // Admin-chosen font family for the loading screen short name. See utils/splashFonts.ts
  // === Loading-screen LOGO (replaces the short-name text when enabled) ===
  splashLogoEnabled?: boolean;   // Default true — show image instead of text on splash
  splashLogoUrl?: string;        // Public path or data: URL. Default '/splash-logo.png'
  splashLogoSize?: number;       // Rendered width in pixels (clamped 60-260). Default 140.
  // Universal Video — when true, hides the bottom Video tab and shows a Video icon in the top header instead.
  universalVideoInTopBar?: boolean;
  // NEW Revision Hub V2 — auto-finds notes for weak topics tracked from MCQ attempts.
  // When true, REVISION button appears in bottom nav after Homework, Profile moves into the menu drawer.
  revisionHubV2Enabled?: boolean;
  // Force Profile to live in the menu drawer regardless of Revision Hub V2 setting.
  // When true, Profile is always in the drawer; when false, Profile only moves to drawer if Revision Hub V2 is enabled.
  profileInMenuForced?: boolean;
  officialAppUrl?: string; // NEW: Play Store Link
  enable3DModels?: boolean; // NEW: 3D Models in Notes
  showMcqMakerCard?: boolean; // NEW: Show MCQ Maker card on student home page
  showHomeResumeFilter?: boolean; // NEW: Show subject filter chips above Home "Continue Reading" card
  mcqAppUrl?: string; // NEW: External MCQ Maker app URL (loaded in iframe)
  bannerConfig?: {
      top: BannerSettings;
      bottom: BannerSettings;
  };
  planBanners?: {
      free?: { enabled: boolean; text: string; bgColor: string; textColor: string };
      basic?: { enabled: boolean; text: string; bgColor: string; textColor: string };
      ultra?: { enabled: boolean; text: string; bgColor: string; textColor: string };
  };
  playerBrandingText?: string; // NEW: Custom Video Player Overlay Text
  playerBlockShare?: boolean; // NEW: Block Share
  iicNstaBadgePos?: {
    portrait?: { bottom: number; right: number };
    landscape?: { bottom: number; right: number };
    fsButton?:  { bottom: number; right: number };
  }; // Admin-saved badge position (% from edge) for portrait & landscape
  playerBadgeLabel?: string;    // Text shown on the IIC×NSTA badge button (default: "IIC×NSTA")
  playerFsButtonLabel?: string; // Text shown on the landscape "go-portrait" button (default: "Portrait")
  hideYtLogoBlocker?: boolean;  // Admin toggle: black blocker over YouTube logo/channel area
  appLogo?: string; // NEW: Base64 Logo Image
  syllabusType?: 'SCHOOL' | 'COMPETITIVE' | 'DUAL'; // Updated: DUAL support
  footerText?: string; // NEW: Customized footer text
  showFooter?: boolean; // NEW: Control footer visibility
  footerColor?: string; // NEW: Customized footer color
  aiName?: string;
  appBackground?: string;
  appBackgroundImage?: string;
  profileBackground?: string;
  themeColor?: string;
  // ── Home Page Section Card Colors (Advanced Theme) ──
  homeClass612CardBg?: string;
  homeClass612CardBorder?: string;
  globalCards3D?: boolean;
  homeAllCards3D?: boolean;
  homeClass612Card3D?: boolean;
  homeCompetitionCardBg?: string;
  homeCompetitionCardBorder?: string;
  homeCompetitionCard3D?: boolean;
  homeQuickAccessCard3D?: boolean;
  homeQuickAccessCardBg?: string;
  homeQuickAccessCardBorder?: string;
  // ── School & Coaching Home Cards ──────────────────────────────────────────
  homeSchoolCardBg?: string;
  homeSchoolCardBorder?: string;
  homeSchoolCard3D?: boolean;
  homeCoachingCardBg?: string;
  homeCoachingCardBorder?: string;
  homeCoachingCard3D?: boolean;
  homeCoachingHomeworkCard3D?: boolean;
  // ── Content List Cards (Book / Lesson / Page list) — same color everywhere ─
  contentListCardBg?: string;
  contentListCardBorder?: string;
  statusBarColor?: string;
  darkThemeColor?: string;
  lightThemeColor?: string;
  ultraThemeColor?: string;
  basicThemeColor?: string;
  freeThemeColor?: string;
  adminActiveTheme?: { id: string; name: string; color: string; expiresAt?: string };
  defaultThemeSnapshot?: { appColor?: string; ultra?: string; basic?: string; free?: string; savedAt?: string };
  adminAppliedTheme?: {
    theme: UserCustomTheme;
    appliedAt: string;
    expiresAt?: string | null;
    targetTier: 'all' | 'ultra' | 'basic' | 'free';
    minLevel?: number | null;
    maxLevel?: number | null;
  };
  officialUltraTheme?: UserCustomTheme;
  officialBasicTheme?: UserCustomTheme;
  officialFreeTheme?: UserCustomTheme;
  adminThemeLibrary?: AdminSavedTheme[];
  themeHistory?: ThemeHistoryEntry[];
  scheduledThemes?: ScheduledTheme[];
  levelScoreOverride?: Record<string, number>;
  isGlobalFreeMode?: boolean; // NEW: Global Free Mode
  watermarkOpacity?: number; // 0.0 to 1.0
  watermarkSize?: number; // px
  watermarkAngle?: number; // deg
  watermarkPosition?: { top: string, left: string }; // NEW: Custom Position
  customBloggerVideoUrl?: string; // Custom Page video URL
  showUserWatermark?: boolean; // Toggle User Name Overlay
  maintenanceMode?: boolean;
  maintenanceMessage?: string;
  customCSS?: string;
  apiKeys?: any[]; // Legacy Gemini Keys
  groqApiKeys?: string[]; // NEW: Groq Keys
  geminiApiKeys?: string[]; // NEW: Gemini Keys
  deletedGroqKeys?: { key: string, deletedAt: number }[]; // NEW: Recycle Bin
  adminCode?: string;
  adminEmail?: string;
  adminPhones?: {id: string, number: string, name: string, isDefault?: boolean}[];
  paymentNumbers?: { id: string, number: string, name: string, dailyClicks: number, lastResetDate: string, highTraffic?: boolean }[];
  defaultAdminPermissions?: string[];
  welcomeTitle?: string;
  welcomeMessage?: string;
  termsText?: string;
  supportEmail?: string;
  aiModel?: string;
  aiInstruction?: string;
  aiPromptNotes?: string;
  aiPromptNotesPremium?: string;
  aiPromptMCQ?: string;
  aiPromptNotesCompetition?: string;
  aiPromptNotesPremiumCompetition?: string;
  aiPromptMCQCompetition?: string;
  aiPromptNotesCBSE?: string;
  aiPromptNotesPremiumCBSE?: string;
  aiPromptMCQCBSE?: string;
  aiPromptNotesCompetitionCBSE?: string;
  aiPromptNotesPremiumCompetitionCBSE?: string;
  aiPromptMCQCompetitionCBSE?: string;
  aiPromptNotesBSEB?: string;
  aiPromptNotesPremiumBSEB?: string;
  aiPromptMCQBSEB?: string;
  aiPromptNotesCompetitionBSEB?: string;
  aiPromptNotesPremiumCompetitionBSEB?: string;
  aiPromptMCQCompetitionBSEB?: string;
  forceRefreshTimestamp?: string;
  marqueeLines?: string[];
  liveMessage1?: string;
  liveMessage2?: string;
  wheelRewards?: any[];
  chatCost?: number;
  chatMode?: 'GLOBAL' | 'ROOMS'; // NEW
  chatCooldownHours?: number; // NEW
  chatEditTimeLimit?: number; // NEW
  allowStudentCommunityMcq?: boolean; // NEW: Allow students to send MCQs in community chat
  hideGlobalChat?: boolean; // NEW: Hide Global tab in community chat
  featuredItems?: FeaturedItem[]; // NEW
  aiUsageSplit?: any; // NEW (for stats)
  dailyReward?: number;
  signupBonus?: number;
  rewardExpiryHours?: number; // How long rewards stay claimable (default 12)
  mcqDailyMinimum?: number; // Min MCQs per day for reward (default 50)
  storeVisitDiscountPercent?: number; // % discount sent to mailbox when non-subscriber visits Store (default 10)
  storeVisitDiscountEnabled?: boolean; // Master toggle for visit-count based discount in Store
  storeVisitDiscountTiers?: ('FREE' | 'BASIC' | 'ULTRA')[]; // Which user tiers get visit discount
  storeVisitDiscountRules?: { visits: number; discountPercent: number }[]; // visit count thresholds → discount %
  htmlUnlockCost?: number; // Credits required for free/basic users to unlock HTML write view per session (default 5)
  basicHtmlDailyLimit?: number; // Free HTML view sessions per day for Basic subscribers (default 3)
  mcqRewardRules?: MCQRewardRule[];

  // LEVEL SYSTEM (Admin Config)
  isLevelSystemEnabled?: boolean;
  levelConfig?: { level: number; unlockedFeatures: string[] }[]; // Admin sets this

  isGameEnabled?: boolean;
  allowSignup?: boolean;
  showGoogleLogin?: boolean; // NEW: Toggle Google Auth on Login Screen
  loginMessage?: string;
  gameCost?: number;
  spinLimitUltra?: number;
  spinLimitBasic?: number;
  spinLimitFree?: number;
  spinGameTypes?: SpinGameType[]; // Multiple spin game types (free/credit-based)
  allowedClasses?: string[];
  allowedBoards?: string[];
  allowedStreams?: string[];
  hiddenSubjects?: string[];
  hiddenClasses?: string[]; // NEW: Granular Class Hiding
  hiddenChapters?: string[]; // NEW: Granular Chapter Hiding
  hiddenTopBarButtons?: string[]; // NEW: Per-button top bar hide/unhide (CREDITS, LIGHTNING, NOTIFICATION, SALE, STREAK)
  topBarEffects?: Array<{ id: string; enabled: boolean; color: string; speed?: number }>; // Admin-configurable top bar visual effects
  topBarAutoScroll?: boolean; // Auto-scroll the top bar button strip left/right
  topBarAutoScrollInterval?: number; // Seconds between each scroll step (default 3)
  profileBarEffects?: Array<{ id: string; enabled: boolean; color: string; speed?: number }>; // Separate effects for Profile page header card
  hiddenHomeButtons?: string[]; // NEW: Per-button home grid hide/unhide (feature IDs)
  hiddenBottomNavButtons?: string[]; // NEW: Per-button bottom nav hide/unhide (HOMEWORK, REVISION, IMPORTANT, VIDEO, APPSTORE, etc.)
  contentVisibility?: { // NEW: Global Content Type Toggles
      VIDEO?: boolean;
      PDF?: boolean;
      MCQ?: boolean;
      AUDIO?: boolean;
  };
  // EXPLORE PAGE CONFIG
  showMorningInsight?: boolean; // NEW: Toggle Morning Banner
  showAiPromo?: boolean; // NEW: Toggle AI Banner
  showChallengesBanner?: boolean; // NEW: Toggle Live Challenges
  exploreBanners?: ExploreBanner[]; // NEW: Dynamic Explore Banners
  featureConfig?: Record<string, any>; // NEW: Mapped Feature Control
  featureAccess?: FeatureAccessConfig[]; // NEW: Granular Feature Control (Legacy Array)
  featureCosts?: FeatureCostConfig[]; // NEW: Granular Cost Control
  hiddenFeatures?: string[]; // NEW: Explicit Hidden Features List
  loginBonusConfig?: LoginBonusConfig; // NEW: Login Bonus Settings
  storageCapacity?: string;
  isPaymentEnabled?: boolean;
  upiId?: string;
  upiName?: string;
  qrCodeUrl?: string;
  paymentInstructions?: string;
  packages?: CreditPackage[];
  subscriptionPlans?: SubscriptionPlan[];
  startupAd?: StartupConfig;
  // NEW: 3-Tier Popup Control (Free vs Ultra)
  appFeatures?: AppFeature[];
  profileEditCost?: number;
  nameChangeCost?: number;
  defaultVideoCost?: number;
  defaultPdfCost?: number; // NEW
  videoFreeLimitBasic?: number; // Free videos/day for Basic (default 5)
  videoFreeLimitUltra?: number; // Free videos/day for Ultra (default 10)
  pdfFreeLimitBasic?: number; // Free PDFs/day for Basic (default 5)
  pdfFreeLimitUltra?: number; // Free PDFs/day for Ultra (default 10)
  writeModeFreeLimitBasic?: number; // Free write modes/day for Basic (default 5)
  writeModeFreeLimitUltra?: number; // Free write modes/day for Ultra (default 10)
  writeModeCreditFree?: number; // Write mode cost for Free users (default 5)
  writeModeCreditPaid?: number; // Write mode cost after free limit (default 10)
  writeModeMaxLimit?: number; // After this many uses, cost becomes 20 for all (default 20)
  deepDiveCost?: number; // NEW
  audioSlideCost?: number; // NEW
  enableMcqUnlockRestriction?: boolean; // NEW
  lessonUnlockPolicy?: 'SEQUENTIAL_100_MCQ' | 'ALL_OPEN'; // NEW
  externalApps?: ExternalApp[]; // NEW
  downloadApps?: DownloadApp[]; // NEW: In-app App Store entries (download links)
  appStorePageHidden?: boolean; // NEW: Hide the App Store tab/page for students
  starredPageHidden?: boolean;  // Hide the Important/GK starred notes tab from nav
  chatRooms?: ChatRoom[]; // NEW
  engagementRewards?: EngagementReward[];
  prizeRules?: PrizeRule[]; // NEW: Prize Configuration
  weeklyTests?: WeeklyTest[];
  dailyChallenges?: Challenge20[]; // NEW: Daily Challenges
  noticeText?: string;
  aiLoadingImage?: string;
  // NEW: Feature Popup Config
  featurePopup?: {
    enabled: boolean;
    intervalMinutes: number; // e.g., 60 for 1 hour
    freeFeatures: string[];
    premiumFeatures: string[];
    showToPremiumUsers: boolean;
    showNearExpiryHours: number; // 24
  };
  adminCustomPopups?: {
    enabled: boolean;
    title: string;
    message: string;
    type: 'DISCOUNT' | 'FREE_CREDIT' | 'FREE_ACCESS' | 'SUBSCRIPTION' | 'EXPIRY' | 'INFO';
    actionText?: string;
    actionUrl?: string;
    copyableText?: string;
    subject?: string;
    class?: string;
    lesson?: string;
    showTo: 'ALL' | 'FREE' | 'PREMIUM';
  }[];
  popupConfigs?: {
      isExpiryWarningEnabled: boolean;
      expiryWarningHours: number;
      expiryWarningIntervalMinutes: number;
      isUpsellEnabled: boolean;
      upsellPopupIntervalMinutes: number;
  };
  threeTierPopupConfig?: {
    enabled: boolean;
    autoCloseSeconds: number;
    skipDelaySeconds: number;
    showToPremium: boolean;
    intervalMinutes?: number;
    showNearExpiryHours?: number;
  };
  creditFreeEvent?: {
    enabled: boolean;
    eventName?: string;
    startsAt?: string;
    endsAt?: string;
  };
  globalFreeAccessEvent?: {
    enabled: boolean;
    eventName?: string;
    startsAt?: string;
    endsAt?: string;
  };
  dailyLimitBoostEvent?: {
    enabled: boolean;
    eventName?: string;
    startsAt?: string;
    endsAt?: string;
    mcqBoostFree?: number;
    mcqBoostBasic?: number;
    mcqBoostUltra?: number;
  };
  themeStudioEvent?: {
    enabled: boolean;
    eventName?: string;
    startsAt?: string;
    endsAt?: string;
    days?: number;
  };
  creditBonusEvent?: {
    enabled: boolean;
    eventName?: string;
    startsAt?: string;
    endsAt?: string;
    bonusPercent: number;
    applyToMcqPrize?: boolean;
    applyToGifts?: boolean;
    applyToLoginBonus?: boolean;
  };
  dailyChallengeConfig?: {
    mode: 'AUTO' | 'MANUAL';
    rewardPercentage: number;
    selectedChapterIds?: string[];
    autoChallengeEnabled?: boolean; // true = popup auto-triggers daily; false = admin ne band kar diya
  };
  themeConfig?: {
    freeTheme: 'BASIC' | 'ULTRA' | 'DARK' | 'LIGHT';
    enableTop3Gold: boolean;
  };
  isCompetitionModeEnabled?: boolean; // NEW: Toggle Competition Mode globally
  dashboardLayout?: Record<string, { id: string, visible: boolean, label?: string, order?: number }>; // NEW: Layout Config
  paymentDisabledMessage?: string;
  showTermsPopup?: boolean;
  showWelcomePopup?: boolean;
  welcomePopupTarget?: 'ALL' | 'FREE_ONLY' | 'ULTRA_ONLY';
  scoreBoostEvent?: {
    enabled: boolean;
    eventName: string;
    boostPercent: number;
    themeStudioEnabled?: boolean;
    themeStudioDays?: number;
    endsAt?: string;
    startsAt?: string;
  };
  specialDiscountEvent?: {
    enabled: boolean;
    eventName: string; // e.g., "Diwali Offer"
    discountPercent: number;
    couponCode?: string; // Discount coupon code shown in mailbox
    showToFreeUsers: boolean;
    showToPremiumUsers: boolean;
    renewalDiscountPercent?: number; // Extra discount for already subscribed users
    endsAt?: string; // ISO Date for countdown
    startsAt?: string; // ISO Date for when to auto-start
    duration?: {
      years: number;
      months: number;
      days: number;
      hours: number;
      minutes: number;
      seconds: number;
    };
    cooldownSettings?: {
      years: number;
      months: number;
      days: number;
      hours: number;
      minutes: number;
      seconds: number;
    };
    ultraDiscountConfig?: {
      startsAt: string;
      endsAt: string;
      years: number;
      months: number;
      days: number;
      hours: number;
      minutes: number;
      seconds: number;
    };
  };
  
  // NEW: App Modes (Global Control)
  appMode?: {
      allowedModesForFree: ('SCHOOL' | 'COMPETITION')[]; // Modes visible to Free users
      allowedModesForPremium: ('SCHOOL' | 'COMPETITION')[]; // Modes visible to Premium users
      accessTier: 'FREE_ONLY' | 'FREE_BASIC' | 'ALL_ACCESS'; // Controls active business model
  };
  latestVersion?: string; // NEW: Force Update Version
  updateUrl?: string; // NEW: Update Link
  launchDate?: string; // NEW: Timer for App Launch (ISO)
  updateGracePeriodDays?: number; // Days before update becomes forced (Default 7)
  updatePopupDurationSeconds?: number; // Seconds to show popup (Default 0 = Infinite)
  updateGracePeriod?: TimeConfig; // NEW: Granular Grace Period
  updatePopupFrequency?: FrequencyConfig; // NEW: Popup Recurrence Frequency

  // AI Config
  aiSafetyLock?: boolean; // NEW: Kill Switch
  isAiEnabled?: boolean;
  aiLimits?: {
      free: number;
      basic: number;
      ultra: number;
  };
  aiNotesPrompt?: string;
  developedBy?: string;
  isMcqRegenerationEnabled?: boolean;
  aiPilotRatio?: number; // NEW: 80/20 Rule
  aiDailyLimitPerKey?: number; // NEW: Quota Management
  isAutoPilotEnabled?: boolean; // NEW: AI Auto-Pilot Toggle
  autoPilotConfig?: {           // NEW: AI Auto-Pilot Configuration
      targetClasses: string[];
      targetBoards: string[];
      targetSubjects?: string[]; // New: Filter by Subject
      contentTypes: ('NOTES' | 'MCQ')[];
      requireApproval?: boolean; // NEW: Admin Approval Flow
  };
  tierPermissions?: {
      FREE: string[];
      BASIC: string[];
      ULTRA: string[];
  };
  areTopicNotesHiddenGlobally?: boolean; // NEW: Global Topic Notes Toggle
  featureBadges?: Record<string, 'NEW' | 'UPGRADE' | 'NORMAL'>; // NEW: Feature Badges
  storeFeatures?: { basic: string[], ultra: string[] }; // NEW: Dynamic Store Features
  isAutoTtsEnabled?: boolean; // NEW: Global Auto TTS Toggle
  cacheClearDays?: number; // NEW: Admin controlled cache cleanup interval
  planComparison?: FeatureCategory[]; // NEW: Admin Configurable Feature Matrix
  revisionConfig?: RevisionConfig; // NEW: Dynamic Revision Logic
  isWatermarkEnabled?: boolean; // NEW: Global Watermark Toggle
  isLogoutEnabled?: boolean; // NEW: Global Logout Toggle
}

export interface RevisionConfig {
    trackWrongAnswers?: boolean;
    thresholds: {
        strong: number; // e.g., 80
        average: number; // e.g., 50 (implied weak < 50)
        mastery: number; // e.g., 80 (score needed for mastery count)
    };
    mastery: {
        requiredCount: number; // e.g., 2
    };
    intervals: {
        // Stored in seconds for simplicity
        weak: { revision: number; mcq: number };
        average: { revision: number; mcq: number };
        strong: { revision: number; mcq: number };
        mastered: { revision: number; mcq: number };
    };
}

export interface ContentInfoItem {
  enabled: boolean;
  title: string;
  details: string; // Multiline
  bestFor: string; // Multiline
}

export interface ContentInfoConfig {
  freeNotes: ContentInfoItem;
  premiumNotes: ContentInfoItem;
  freeVideo: ContentInfoItem;
  premiumVideo: ContentInfoItem;
}

export interface ChatRoom {
  id: string;
  name: string;
  type: 'PUBLIC' | 'PRIVATE' | 'ANNOUNCEMENT'; // PUBLIC = Open to all, PRIVATE = Invite only (future), ANNOUNCEMENT = Admin only post
  enabled: boolean;
  icon?: string; // Icon name from Lucide
  description?: string;
}

export interface AppFeature {
  id: string;
  title: string;
  enabled: boolean;
  order: number;
  category?: string; // Analysis, MCQ, Revision, etc.
}

export interface SpinReward {
  id: string;
  type: 'COINS' | 'SUBSCRIPTION' | 'GIFT_CODE';
  value: number | string; // Coins amount or Sub Tier (e.g., 'WEEKLY_BASIC') or gift code string
  label: string;
  probability?: number; // Optional weighting (0-100, sum should be 100)
  color?: string; // Optional custom color
  giftCode?: string; // For GIFT_CODE type: the actual code to deliver
  expiryHours?: number; // For GIFT_CODE type: how many hours the code is valid after winning
}

export interface SpinGameType {
  id: string;
  name: string; // e.g., "Free Spin", "Lucky Spin", "Premium Spin"
  cost: number; // 0 = free, >0 = credit-based
  description?: string;
  dailyLimitFree?: number;
  dailyLimitBasic?: number;
  dailyLimitUltra?: number;
  rewards: SpinReward[]; // Each type can have its own rewards/probabilities
  color?: string; // Accent color for the UI card
  emoji?: string; // Display emoji
}

export interface FeaturedItem {
  id: string;
  title: string; // "Trigonometry MCQs"
  subtitle?: string; // "Class 10 Math"
  board: Board;
  classLevel: ClassLevel;
  stream: Stream | null;
  subject: Subject; // Store full object for easy reconstruction
  chapter: Chapter; // Store full object
  type: 'MCQ' | 'PDF' | 'VIDEO'; // Simple mapping to tab
}

export interface EngagementReward {
  id: string;
  seconds: number; // e.g., 600 for 10 mins
  type: 'COINS' | 'SUBSCRIPTION';
  amount?: number; // for COINS
  subTier?: 'WEEKLY' | 'MONTHLY' | 'LIFETIME'; // for SUBSCRIPTION
  subLevel?: 'BASIC' | 'ULTRA'; // 'BASIC' or 'ULTRA'
  durationHours?: number; // How long the sub lasts
  label: string; // "10 Mins Study: 2 Coins"
  enabled: boolean;
  // Redeem Code Auto-Generation
  generateRedeemCode?: boolean;
  redeemCodeType?: 'CREDITS' | 'SUBSCRIPTION' | 'DISCOUNT' | 'CONTENT_UNLOCK' | 'TOPBAR_EFFECT_COLOR';
  redeemCodeAmount?: number;
  redeemCodeDiscountPercent?: number;
  redeemCodeSubTier?: 'WEEKLY' | 'MONTHLY' | 'LIFETIME';
  redeemCodeSubLevel?: 'BASIC' | 'ULTRA';
  redeemCodeExpiryHours?: number;
  redeemCodeContentId?: string;
  redeemCodeEffectColor?: string;
}

export interface MCQRewardRule {
  id: string;
  minPercentage: number;
  rewardType: 'COINS' | 'SUBSCRIPTION';
  rewardAmount?: number;
  rewardSubTier?: 'WEEKLY' | 'MONTHLY' | 'LIFETIME';
  rewardSubLevel?: 'BASIC' | 'ULTRA';
  rewardDurationHours?: number;
  label: string;
  enabled: boolean;
}

export interface GiftCode {
  id: string;
  code: string;
  type: 'CREDITS' | 'SUBSCRIPTION' | 'DISCOUNT' | 'CONTENT_UNLOCK' | 'TOPBAR_EFFECT_COLOR' | 'TOPBAR_EFFECT_ID' | 'SCORE' | 'SCORE_BOOST' | 'SCORE_LIMIT_BOOST' | 'THEME_COLOR'; // New: Type of code
  scoreBoostPercent?: number; // For SCORE_BOOST type
  scoreBoostDurationHours?: number; // Hours the boost lasts
  scoreLimitBoostPercent?: number; // For SCORE_LIMIT_BOOST type — temporary daily limit increase %
  scoreLimitBoostDurationHours?: number; // How long the daily limit boost lasts (hours)
  amount?: number; // For Credits
  discountPercent?: number; // For Discount
  effectColor?: string; // For TOPBAR_EFFECT_COLOR — hex color
  effectId?: string; // For TOPBAR_EFFECT_ID — specific animation effect id
  themeColor?: string; // For THEME_COLOR — hex color for temp app theme
  themeDurationHours?: number; // For THEME_COLOR — hours the color lasts
  subTier?: 'WEEKLY' | 'MONTHLY' | '3_MONTHLY' | 'YEARLY' | 'LIFETIME' | 'CUSTOM'; // For Subscription
  subLevel?: 'BASIC' | 'ULTRA'; // For Subscription
  contentId?: string; // For Content Unlock
  contentType?: string; // For Content Unlock (VIDEO, PDF, MCQ)
  duration?: { // For Custom Subscription
      years: number;
      months: number;
      days: number;
      hours: number;
      minutes: number;
      seconds: number;
  };
  createdAt: string;
  expiresAt?: string;
  isRedeemed: boolean;
  redeemedBy?: string | string[]; // User ID or List of User IDs
  redeemedDate?: string;
  generatedBy: string; // Admin ID (or name)
  maxUses?: number; // New: Multiple use support
  usedCount?: number; // New: Track usage
}

export interface PendingReward {
  id: string;
  type: 'COINS' | 'SUBSCRIPTION';
  amount?: number; // For Coins
  subTier?: 'WEEKLY' | 'MONTHLY' | 'LIFETIME'; // For Sub
  subLevel?: 'BASIC' | 'ULTRA';
  durationHours?: number;
  expiresAt: string;
  unlockDate?: string; // NEW: When this reward becomes claimable
  label: string;
}

export interface ChatMessage {
  id: string;
  userId: string;
  userName: string;
  userRole?: Role;
  text?: string;
  timestamp: string;
  isDeleted?: boolean;
  deletedAt?: string;
  replyTo?: {
    id: string;
    userName: string;
    text: string;
  };
}

export interface IICPost {
  id: string;
  type: 'TEXT' | 'IMAGE' | 'VIDEO';
  title?: string;
  content: string; // Text content, Base64 Image string, or Video URL
  timestamp: string;
  authorName: string;
}

export interface Subject {
  id: string;
  name: string;
  icon: string;
  color: string;
}

export interface Chapter {
  id: string;
  title: string;
  description?: string;
  serialNumber?: string; // Custom display number
  // For Lucent admin lessons: lowest pageNo across the lesson's pages. When
  // present, the chapter card renders a "PG X" badge instead of "CH 01".
  pageNo?: string;
}

export interface MCQItem {
  question: string;
  statements?: string[];
  options: string[];
  correctAnswer: number; // Index 0-3
  explanation: string;
  mnemonic?: string; // Memory Trick
  concept?: string; // Full concept explanation
  topic?: string; // NEW
  examTip?: string; // Exam Tip
  commonMistake?: string; // Common Mistake
  difficulty?: 'EASY' | 'MEDIUM' | 'HARD'; // Difficulty Level
  difficultyLevel?: string;
  pyqInspired?: string;
}

// NEW: Performance Analytics
export type PerformanceTag = 'EXCELLENT' | 'GOOD' | 'BAD' | 'VERY_BAD';

export interface MCQResult {
  id: string; // Unique Result ID
  userId: string;
  chapterId: string;
  subjectId: string;
  subjectName: string;
  chapterTitle: string;
  date: string;
  
  totalQuestions: number;
  correctCount: number;
  wrongCount: number;
  score: number;
  
  totalTimeSeconds: number; // Total time spent in session
  averageTimePerQuestion: number;
  performanceTag: PerformanceTag; // Overall Tag
  
  questionTimes?: number[]; // Array of seconds taken per question (optional detail)
  
  // OMR DATA
  classLevel?: string;
  topic?: string; // NEW: If test was specific to a topic
  omrData?: {
      qIndex: number;
      selected: number; // -1 if skipped
      correct: number;
      timeSpent?: number; // Time in seconds
  }[];

  wrongQuestions?: {
    question: string;
  statements?: string[];
    qIndex: number;
    correctAnswer?: string | number;
    explanation?: string;
  }[];
  topicAnalysis?: Record<string, { correct: number, total: number, percentage: number }>; // NEW: Granular Analysis
  ultraAnalysisReport?: string;
}

export interface UniversalAnalysisLog {
  id: string;
  userId: string;
  userName: string;
  date: string;
  subject: string;
  chapter: string;
  score: number;
  totalQuestions: number;
  userPrompt: string; // The data sent to AI
  aiResponse: string; // The analysis
  cost: number;
}

export interface LeaderboardEntry {
    id: string;
    userId: string;
    userName: string;
    score: number;
    total: number;
    date: string;
    topic: string;
    challengeId?: string; // Shared challenge ID for fair leaderboard comparison
}

export interface ActivityLogEntry {
  id: string;
  userId: string;
  userName: string;
  action: string; // 'LOGIN', 'SIGNUP', 'TEST', 'CONTENT', 'ADMIN'
  details: string;
  timestamp: string;
  role: Role;
}

export interface HtmlModule {
  id: string;
  title: string;
  url: string;
  price: number;
  access: 'FREE' | 'BASIC' | 'ULTRA';
}

export interface DeepDiveEntry {
  audioUrl?: string; // NEW: Custom Audio Link
  id: string;
  title?: string; // NEW: Topic Name
  htmlContent: string;
  pdfLink: string;
}

export interface AdditionalNoteEntry {
  audioUrl?: string; // NEW: Custom Audio Link
  id: string;
  title: string;
  noteContent: string;
  pdfLink: string;
}

export interface QuickNoteEntry {
  id: string;
  title: string;
  content: string;
}

export interface PremiumNoteSlot {
  audioUrl?: string; // New: Custom Audio Link
  id: string;
  title: string;
  type?: 'PDF' | 'HTML'; // New: Support HTML content
  url: string;
  content?: string; // New: HTML content
  color: string; // Hex or Class
  access: 'FREE' | 'BASIC' | 'ULTRA';
}

export interface LessonContent {
  id: string; // unique ID for history
  title: string;
  subtitle: string;
  content: string; // URL for PDF/Link Mode
  type: ContentType;
  dateCreated: string;
  subjectName: string;
  mcqData?: MCQItem[]; // Structure for MCQ mode
  
  // DUAL SYLLABUS CONTENT
  schoolVideoPlaylist?: {title: string, url: string, price?: number, access?: 'FREE' | 'BASIC' | 'ULTRA'}[];
  competitionVideoPlaylist?: {title: string, url: string, price?: number, access?: 'FREE' | 'BASIC' | 'ULTRA'}[];

  schoolPremiumVideoPlaylist?: {title: string, url: string, price?: number, access?: 'FREE' | 'BASIC' | 'ULTRA'}[];
  competitionPremiumVideoPlaylist?: {title: string, url: string, price?: number, access?: 'FREE' | 'BASIC' | 'ULTRA'}[];

  schoolAudioPlaylist?: {title: string, url: string, price?: number, access?: 'FREE' | 'BASIC' | 'ULTRA'}[];
  competitionAudioPlaylist?: {title: string, url: string, price?: number, access?: 'FREE' | 'BASIC' | 'ULTRA'}[];

  schoolPdfLink?: string;
  schoolPdfPrice?: number;
  competitionPdfLink?: string;
  competitionPdfPrice?: number;
  
  schoolPdfPremiumSlots?: PremiumNoteSlot[];
  competitionPdfPremiumSlots?: PremiumNoteSlot[];

  // HINDI DUAL CONTENT
  schoolPremiumNotesHtml_HI?: string;
  competitionPremiumNotesHtml_HI?: string;
  manualMcqData_HI?: MCQItem[];

  videoPlaylist?: {title: string, url: string, price?: number, access?: 'FREE' | 'BASIC' | 'ULTRA'}[]; // LEGACY
  audioPlaylist?: {title: string, url: string, price?: number, access?: 'FREE' | 'BASIC' | 'ULTRA'}[]; // LEGACY

  // CUSTOM SLOTS (6/6/6)
  customPdf?: { id: string, name: string, link: string, price: number }[];
  customVideo?: { id: string, name: string, link: string, price: number }[];
  customMcq?: { id: string, name: string, data: MCQItem[], price: number }[];
  
  // HTML INTERACTIVE MODULES (10 Slots)
  htmlModules?: HtmlModule[];

  // PREMIUM NOTE SLOTS (20 Slots)
  premiumNoteSlots?: PremiumNoteSlot[];

  videoPrice?: number; // Global or default video price
  ultraPdfLink?: string; // Ultra PDF
  ultraPdfPrice?: number; // Ultra PDF Price
  aiImageLink?: string; // NEW: AI Generated Image Notes
  aiHtmlContent?: string; // NEW: HTML Content for AI Notes
  aiImagePrice?: number; // Price for AI Image Notes
  isComingSoon?: boolean; // If content is missing
  userAnswers?: Record<number, number>; // Saved answers for History/Analysis
  is_free?: boolean; // NEW: Explicit Flag
  is_premium?: boolean; // NEW: Explicit Flag

  // VISIBILITY FLAGS
  isNotesHidden?: boolean;
  isMcqHidden?: boolean;
  isVideoHidden?: boolean;
  isAudioHidden?: boolean;

  // DUAL STORAGE (Free vs Premium)
  schoolFreeNotesHtml?: string;
  schoolPremiumNotesHtml?: string;
  competitionFreeNotesHtml?: string;
  competitionPremiumNotesHtml?: string;

  deepDiveNotesHtml?: string; // NEW: Deep Dive Notes (TTS Source)
  competitionDeepDiveNotesHtml?: string; // NEW: Competition Mode Deep Dive Notes

  deepDiveEntries?: DeepDiveEntry[]; // NEW: Unlimited Deep Dive Entries
  additionalNotes?: AdditionalNoteEntry[]; // NEW: Additional Notes
  quickNotes?: QuickNoteEntry[]; // NEW: Quick Notes

  // MULTI-HTML SECTIONS: Multiple HTML blocks shown on same notes page
  htmlSections?: { id: string; title?: string; html: string; chunkNotes?: string }[];
  schoolHtmlSections?: { id: string; title?: string; html: string; chunkNotes?: string }[];
  competitionHtmlSections?: { id: string; title?: string; html: string; chunkNotes?: string }[];

  // MODE SPECIFIC UNLIMITED ENTRIES
  schoolDeepDiveEntries?: DeepDiveEntry[];
  competitionDeepDiveEntries?: DeepDiveEntry[];
  schoolAdditionalNotes?: AdditionalNoteEntry[];
  competitionAdditionalNotes?: AdditionalNoteEntry[];
  schoolQuickNotes?: QuickNoteEntry[];
  competitionQuickNotes?: QuickNoteEntry[];

  // NEW TOPIC BASED CONTENT
  topicNotes?: { id: string, title: string, content: string, isPremium: boolean, topic: string }[];
  topicVideos?: { id: string, title: string, url: string, isPremium: boolean, topic: string }[];

  // ANALYSIS FLOW
  analysisType?: 'FREE' | 'PREMIUM';
  aiAnalysisText?: string;
  topic?: string; // Filtered Topic
  analytics?: any; // For passing full analytics data
}

export type ViewState = 'ONBOARDING' | 'BOARDS' | 'CLASSES' | 'STREAMS' | 'SUBJECTS' | 'CHAPTERS' | 'LESSON' | 'ADMIN_DASHBOARD' | 'AUDIO_STUDIO' | 'STUDENT_DASHBOARD' | 'UNIVERSAL_CHAT' | 'RULES' | 'IIC' | 'LEADERBOARD';

export interface WeeklyTest {
  id: string;
  name: string;
  description: string;
  isActive: boolean;
  classLevel: ClassLevel;
  questions: MCQItem[];
  totalQuestions: number;
  passingScore: number;
  createdAt: string;
  durationMinutes?: number; // Default 120 (2 hours)
  autoSubmitEnabled?: boolean; // Auto-submit after timeout
  selectedSubjects?: string[]; // Subject IDs included in this test
  selectedChapters?: string[]; // Chapter IDs included in this test (mix from multiple)
}

// 2.0 FEATURES
export interface Challenge20 {
    id: string; // "challenge-{timestamp}"
    title: string;
    description?: string;
    questions: MCQItem[];
    createdAt: string; // ISO
    expiryDate: string; // ISO (createdAt + 24h)
    type: 'DAILY_CHALLENGE' | 'WEEKLY_TEST';
    classLevel: ClassLevel;
    isAutoGenerated: boolean; // True if "Auto Mix" used
    isActive: boolean;
    durationMinutes?: number; // NEW: Admin customized timer
}

export interface QuestionBankItem {
    id: string; // Unique ID
    question: MCQItem;
    subject: string;
    topic?: string;
    classLevel: ClassLevel;
    difficulty?: 'EASY' | 'MEDIUM' | 'HARD';
    createdAt: string;
    source: 'AI' | 'MANUAL';
}

export interface StudentTestAttempt {
  testId: string;
  userId: string;
  startedAt: string; // ISO timestamp
  submittedAt?: string;
  score?: number;
  answers: Record<number, number>; // question index -> selected answer index
}

export type StudentTab = 'HOME' | 'EXPLORE' | 'COURSES' | 'ROUTINE' | 'HISTORY' | 'REDEEM' | 'PREMIUM' | 'GAME' | 'EARN' | 'WEEKLY_TEST' | 'PROFILE' | 'LEADERBOARD' | 'STORE' | 'VIDEO' | 'PDF' | 'MCQ' | 'ANALYTICS' | 'PRIZES' | 'REWARDS' | 'UPDATES' | 'IIC_GALLERY' | 'SUPPORT' | 'CUSTOM_PAGE' | 'AI_CHAT' | 'REVISION' | 'MCQ_REVIEW' | 'AI_HUB' | 'AI_STUDIO' | 'UNIVERSAL_VIDEO' | 'DOWNLOADS' | 'APP_STORE' | 'THEME_BUILDER';

export interface UserCustomTheme {
  id: string;
  userId: string;
  userName: string;
  bgColor: string;
  accentColor: string;
  textColor: string;
  cardColor: string;
  topBarStart?: string;
  topBarEnd?: string;
  navBg?: string;
  navActive?: string;
  navInactive?: string;
  navActiveColors?: string[];
  navBorder?: string;
  cardBg?: string;
  cardBorder?: string;
  btnStart?: string;
  btnEnd?: string;
  textSecondary?: string;
  accentGlow?: string;
  progressColor?: string;
  flashcardBg1?: string;
  flashcardBg2?: string;
  chapterAccent?: string;
  mcqTabActive?: string;
  topBarEffect?: string;
  animColor?: string;
  animSpeed?: number;
  themeName?: string;
  themeEmoji?: string;
  createdAt: string;
  appliedUntil?: string;
  publishedAt?: string;
  publishedName?: string;
  likes?: number;
}

export interface AdminSavedTheme {
  id: string;
  name: string;
  themeData: UserCustomTheme;
  createdAt: string;
  createdBy?: string;
}

export interface ThemeHistoryEntry {
  id: string;
  name: string;
  themeData: UserCustomTheme;
  targetTier: 'all' | 'ultra' | 'basic' | 'free';
  appliedAt: string;
  expiresAt: string | null;
}

export interface ScheduledTheme {
  id: string;
  themeId: string;
  themeName: string;
  themeEmoji: string;
  themeColors: {
    bgColor: string;
    topBarStart: string;
    topBarEnd: string;
    navBg: string;
    navActive: string;
    navInactive: string;
    navBorder: string;
    cardBg: string;
    cardBorder: string;
    btnStart: string;
    btnEnd: string;
    textPrimary: string;
    textSecondary: string;
    accentGlow: string;
    progressColor: string;
    [key: string]: string;
  };
  navActiveColors?: string[];
  topBarEffect?: string;
  animColor?: string;
  scheduledAt: string;
  durationHours: number;
  target: 'ALL' | 'FREE' | 'BASIC' | 'ULTRA';
  applyToProfile?: boolean;
  applyToBackground?: boolean;
  createdBy: string;
  createdAt: string;
}

export interface UserCustomAnimation {
  id: string;
  userId: string;
  userName: string;
  effectId: string;
  effectName: string;
  color: string;
  speed: number;
  createdAt: string;
  appliedUntil?: string;
  publishedAt?: string;
  publishedName?: string;
  likes?: number;
}

export type Language = 'English' | 'Hindi';

export interface AppState {
  user: User | null;
  originalAdmin: User | null; // NEW: Track Admin when viewing as user
  view: ViewState;
  selectedBoard: Board | null;
  selectedClass: ClassLevel | null;
  selectedStream: Stream | null;
  selectedSubject: Subject | null;
  selectedChapter: Chapter | null;
  chapters: Chapter[];
  lessonContent: LessonContent | null;
  loading: boolean;
  error: string | null;
  language: Language;
  showWelcome: boolean; // Control welcome popup
  globalMessage: string | null; // Admin Broadcast
  settings: SystemSettings; // New Global Settings
}

// REVISION HUB TYPES
export type TopicStatus = 'WEAK' | 'AVERAGE' | 'STRONG' | 'EXCELLENT';

export interface TopicItem {
    id: string; // Unique ID for list rendering (e.g. chapterId_subTopic)
    chapterId: string;
    chapterName: string; // Name of the parent chapter
    name: string; // Sub-topic name (or Chapter name if no sub-topics)
    score: number; // Inherited or Specific Score
    lastAttempt: string;
    status: TopicStatus;
    nextRevision: string | null; // ISO Date for Notes (Null if waiting for MCQ)
    mcqDueDate: string | null; // ISO Date for MCQ (Null if waiting for Revision)
    subjectId?: string; // NEW
    subjectName?: string;
    isSubTopic: boolean;
    totalQs?: number; // Aggregate stats
    totalCorrect?: number; // Aggregate stats
    notesCount?: number; // NEW: Number of notes available for this topic
    cycleCount?: number; // NEW: Tracking revision cycles
}

export interface FeatureRow {
    name: string;
    free: string;
    basic: string;
    ultra: string;
}

export interface FeatureCategory {
    name: string;
    features: FeatureRow[];
}

export interface DemandEntry {
    id: string;
    userId: string;
    userName: string;
    displayId?: string;
    classLevel?: string;
    board?: string;
    subjectName: string;
    chapterName: string;
    pageNo?: string;
    contentType: 'PDF' | 'VIDEO' | 'MCQ' | 'NOTES' | 'ANY';
    note?: string;
    timestamp: string;
    status: 'PENDING' | 'IN_PROGRESS' | 'DONE' | 'REJECTED';
}

export interface ChatMessage {
    id: string;
    userId: string;
    userName: string;
    role: Role;
    subscriptionLevel?: string;
    type: 'TEXT' | 'MCQ' | 'ADMIN_BROADCAST';
    text?: string;
    mcqData?: {
        question: string;
        options: string[];
        correctAnswer: number;
        explanation?: string;
    };
    isAdminOnly?: boolean;
    timestamp: string;
}

export interface AppFeedbackAnswer {
  questionId: string;
  question: string;
  type: 'rating' | 'text' | 'choice';
  rating?: number;
  text?: string;
  choice?: string;
}

export interface AppFeedbackEntry {
  id: string;
  userId: string;
  userName: string;
  userRole: string;
  userClass?: string;
  userBoard?: string;
  isPremium: boolean;
  subscriptionTier?: string;
  answers: AppFeedbackAnswer[];
  overallRating: number;
  submittedAt: string;
}
